package com.example.habitbuilder.ui.home

data class PopularExperience(
    val title: String,
    val subtitle: String,
    val imageRes: Int
)
