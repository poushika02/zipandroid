package com.example.habitbuilder.ui.onboarding

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.habitbuilder.MainActivity
import com.example.habitbuilder.R
import com.example.habitbuilder.data.model.BasicInfo
import com.example.habitbuilder.data.model.OnboardingRequest
import com.example.habitbuilder.data.repository.OnboardingRepository
import kotlinx.coroutines.launch

class OnboardingCompleteFragment : Fragment() {

    private val repository = OnboardingRepository()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(
            R.layout.fragment_onboarding_complete,
            container,
            false
        )

        val getStartedButton = view.findViewById<Button>(R.id.getStartedButton)
        val backButton = view.findViewById<TextView>(R.id.back_button)
        val titleText = view.findViewById<TextView>(R.id.title)

        // ----------------------------
        // READ DATA FROM PREVIOUS FRAGMENTS
        // ----------------------------
        val userName = arguments?.getString("userName") ?: ""
        val profileType = arguments?.getString("profileType") ?: "ADULT"
        val gender = arguments?.getString("gender") ?: "OTHER"
        val age = arguments?.getInt("age")

        val challenges =
            arguments?.getStringArrayList("challenges") ?: emptyList()

        val interests =
            arguments?.getStringArrayList("interests") ?: emptyList()

        titleText.text = "You're all set, $userName"

        // ----------------------------
        // SUBMIT ONBOARDING
        // ----------------------------
        getStartedButton.setOnClickListener {
            submitOnboarding(
                userName = userName,
                age = age,
                gender = gender,
                profileType = profileType,
                challenges = challenges,
                interests = interests
            )
        }

        backButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        return view
    }

    // --------------------------------------------------
    // API CALL – EXACT OPENAPI STRUCTURE
    // --------------------------------------------------
    private fun submitOnboarding(
        userName: String,
        age: Int?,
        gender: String,
        profileType: String,
        challenges: List<String>,
        interests: List<String>
    ) {
        lifecycleScope.launch {
            try {
                val request = OnboardingRequest(
                    basicInfo = BasicInfo(
                        name = userName,
                        age = age,
                        gender = gender,
                        type = profileType   // MUST be ADULT, CHILD, etc.
                    ),
                    challenges = challenges,
                    interests = interests,
                    availability = emptyMap()
                )

                val response = repository.submitOnboarding(request)

                if (response.isSuccessful) {
                    val intent = Intent(
                        requireActivity(),
                        MainActivity::class.java
                    )
                    intent.flags =
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Onboarding failed (${response.code()})",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
