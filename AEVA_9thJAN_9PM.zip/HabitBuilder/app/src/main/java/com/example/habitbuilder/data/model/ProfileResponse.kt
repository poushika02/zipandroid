package com.example.habitbuilder.data.model

data class ProfileResponse(
    val id: String,
    val name: String,
    val age: Int?,
    val gender: String?,
    val type: String,
    val ownerId: String?,
    val claimCode: String?
)
