package com.example.habitbuilder.network

import com.example.habitbuilder.data.model.GoalResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface GoalApi {

    @GET("/api/v1/goal/profile/{profileId}")
    suspend fun getGoalsByProfile(
        @Path("profileId") profileId: String
    ): Response<List<GoalResponse>>
}
