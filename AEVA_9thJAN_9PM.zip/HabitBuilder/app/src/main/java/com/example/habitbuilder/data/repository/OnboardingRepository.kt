package com.example.habitbuilder.data.repository

import com.example.habitbuilder.data.model.OnboardingRequest
import com.example.habitbuilder.network.ApiClient
import com.example.habitbuilder.network.OnboardingApi

class OnboardingRepository {

    private val api =
        ApiClient.createService(OnboardingApi::class.java)

    suspend fun submitOnboarding(request: OnboardingRequest) =
        api.submitOnboarding(request)

    // ✅ GET ALL PROFILES
    suspend fun getAllProfiles() =
        api.getAllProfiles()
}
