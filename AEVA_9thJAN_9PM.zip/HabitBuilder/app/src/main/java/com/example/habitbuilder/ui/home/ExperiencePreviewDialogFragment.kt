package com.example.habitbuilder.ui.home

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.R
import com.example.habitbuilder.data.repository.TaskRepository
import kotlinx.coroutines.launch

class ExperiencePreviewDialogFragment :
    DialogFragment(),
    DailyTaskAdapter.TaskActionListener {

    private val taskRepository = TaskRepository()
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: DailyTaskAdapter

    // --------------------------------------------------
    // LIFECYCLE
    // --------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NO_TITLE, R.style.CenterDialogStyle)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(
            R.layout.dialog_experience_preview,
            container,
            false
        )
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.apply {
            setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val title = arguments?.getString(ARG_TITLE).orEmpty()
        val description = arguments?.getString(ARG_DESCRIPTION).orEmpty()

        view.findViewById<TextView>(R.id.tvHeroTitle).text = title
        view.findViewById<TextView>(R.id.tvGoalDescription).text = description

        view.findViewById<View>(R.id.btnClose).setOnClickListener {
            dismiss()
        }

        recyclerView = view.findViewById(R.id.rvDailyTasks)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        loadWeekOneTasks()
    }

    // --------------------------------------------------
    // ADAPTER CALLBACKS (✅ FIXED)
    // --------------------------------------------------
    override fun onTaskCompleted(task: DailyTask, rating: Int) {
        Log.d("ExperiencePreview", "Task completed: ${task.id}, rating=$rating")

        lifecycleScope.launch {
            try {
                val score = rating // 5 stars → 100

                val response =
                    taskRepository.updateTaskStatus(
                        taskId = task.id,
                        status = "COMPLETED",
                        score = score,
                        feedback = "GOOD"
                    )

                if (response.isSuccessful) {
                    Log.d("ExperiencePreview", "Task marked COMPLETED")
                } else {
                    Log.e("ExperiencePreview", "Failed to update task")
                }

            } catch (e: Exception) {
                Log.e("ExperiencePreview", "Error updating task", e)
            }
        }
    }

    override fun onTaskNotCompleted(task: DailyTask, reason: String) {
        Log.d("ExperiencePreview", "Task NOT completed: ${task.id}")

        lifecycleScope.launch {
            try {
                val response =
                    taskRepository.updateTaskStatus(
                        taskId = task.id,
                        status = "NOT_COMPLETED",
                        score = 0,
                        feedback = reason
                    )

                if (response.isSuccessful) {
                    Log.d("ExperiencePreview", "Task marked NOT_COMPLETED")
                } else {
                    Log.e("ExperiencePreview", "Failed to update task")
                }

            } catch (e: Exception) {
                Log.e("ExperiencePreview", "Error updating task", e)
            }
        }
    }

    // --------------------------------------------------
    // LOAD WEEK 1 TASKS
    // --------------------------------------------------
    private fun loadWeekOneTasks() {

        val prefs = requireContext()
            .getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)

        val profileId = prefs.getString("profile_id", null)

        if (profileId.isNullOrBlank()) {
            Log.e("ExperiencePreview", "Profile ID missing")
            return
        }

        lifecycleScope.launch {
            try {
                val response = taskRepository.getTasks(profileId)

                if (response.isSuccessful) {

                    val weekOneTasks =
                        response.body()
                            .orEmpty()
                            .filter { it.plan?.weekNumber == 1 }
                            .sortedBy { it.dayOfWeek ?: 1 }
                            .map {
                                DailyTask(
                                    id = it.id,
                                    title = it.title.orEmpty(),
                                    description = it.description.orEmpty(),
                                    scheduledStart = it.scheduledStart ?: "--",
                                    scheduledEnd = it.scheduledEnd ?: "--",
                                    dayOfWeek = it.dayOfWeek ?: 1,
                                    status = it.status ?: "PENDING"
                                )
                            }

                    adapter = DailyTaskAdapter(
                        tasks = weekOneTasks,
                        listener = this@ExperiencePreviewDialogFragment
                    )

                    recyclerView.adapter = adapter

                } else {
                    Log.e("ExperiencePreview", "Task fetch failed")
                }

            } catch (e: Exception) {
                Log.e("ExperiencePreview", "Error loading tasks", e)
            }
        }
    }

    // --------------------------------------------------
    // FACTORY METHOD
    // --------------------------------------------------
    companion object {

        private const val ARG_TITLE = "arg_title"
        private const val ARG_DESCRIPTION = "arg_description"

        fun newInstance(
            title: String,
            description: String
        ): ExperiencePreviewDialogFragment {
            return ExperiencePreviewDialogFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_TITLE, title)
                    putString(ARG_DESCRIPTION, description)
                }
            }
        }
    }
}
