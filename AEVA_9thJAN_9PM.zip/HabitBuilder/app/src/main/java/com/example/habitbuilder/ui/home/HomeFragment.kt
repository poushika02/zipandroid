package com.example.habitbuilder.ui.home

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.HabitBuilderApp
import com.example.habitbuilder.MainActivity
import com.example.habitbuilder.R
import com.example.habitbuilder.data.repository.GoalRepository
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var profileId: String? = null
    private val goalRepository = GoalRepository()

    // --------------------------------------------------
    // LIFECYCLE
    // --------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = HabitBuilderApp.appContext
            .getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)

        profileId = prefs.getString("profile_id", null)

        Log.d("HomeFragment", "Loaded profileId = $profileId")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_homepage, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // --------------------------------------------------
        // HERO TITLE (PROFILE NAME)
        // --------------------------------------------------
        val heroTitle = view.findViewById<TextView>(R.id.tvHeroTitle)

        val prefs = requireContext()
            .getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)

        val profileName = prefs.getString("profile_name", null)

        heroTitle.text =
            if (!profileName.isNullOrBlank()) {
                "$profileName Experiences"
            } else {
                "My Experiences"
            }

        // --------------------------------------------------
        // GOAL TITLE + DESCRIPTION
        // --------------------------------------------------
        val goalTitleText = view.findViewById<TextView>(R.id.tvPopularTitle)
        val goalDescriptionText = view.findViewById<TextView>(R.id.tvGoalDescription)

        if (!profileId.isNullOrBlank()) {
            fetchGoals(profileId!!, goalTitleText, goalDescriptionText, view)
        } else {
            goalTitleText.text = "No profile found"
            goalDescriptionText.text = "Please complete onboarding"
        }

        // --------------------------------------------------
        // RECYCLER VIEW BASE SETUP
        // --------------------------------------------------
        val recyclerView =
            view.findViewById<RecyclerView>(R.id.rvPopularExperiences)

        recyclerView.layoutManager =
            LinearLayoutManager(
                requireContext(),
                LinearLayoutManager.HORIZONTAL,
                false
            )
    }

    override fun onResume() {
        super.onResume()

        val activity = activity as? MainActivity ?: return

        activity.setTopBar(
            title = "My Habits",
            subtitle = "Your daily progress"
        )
    }

    // --------------------------------------------------
    // API CALL: GET /api/v1/goal/profile/{profileId}
    // --------------------------------------------------
    private fun fetchGoals(
        profileId: String,
        titleView: TextView,
        descriptionView: TextView,
        rootView: View
    ) {
        lifecycleScope.launch {
            try {
                Log.d("HomeFragment", "Fetching goals for profileId=$profileId")

                val response = goalRepository.getGoalsByProfile(profileId)

                if (response.isSuccessful) {
                    val goals = response.body().orEmpty()

                    if (goals.isNotEmpty()) {
                        val goal = goals.first()

                        titleView.text = goal.title
                        descriptionView.text =
                            goal.description ?: "Keep going!"

                        val plannedWeeks = goal.plannedWeeks ?: 1
                        val weekCards = generateWeekCards(plannedWeeks)

                        val recyclerView =
                            rootView.findViewById<RecyclerView>(R.id.rvPopularExperiences)

                        recyclerView.adapter =
                            PopularExperienceAdapter(weekCards) { selectedExperience ->
                                openExperiencePreview(selectedExperience)
                            }

                    } else {
                        titleView.text = "No goals yet"
                        descriptionView.text = "Create your first goal to begin"
                    }
                } else {
                    titleView.text = "Unable to load goals"
                }
            } catch (e: Exception) {
                Log.e("HomeFragment", "Error fetching goals", e)
                titleView.text = "Error loading goals"
            }
        }
    }

    // --------------------------------------------------
    // WEEK CARD GENERATOR
    // --------------------------------------------------
    private fun generateWeekCards(plannedWeeks: Int): List<PopularExperience> {
        return (1..plannedWeeks).map { week ->
            PopularExperience(
                title = "Week $week",
                subtitle = "Your plan for week $week",
                imageRes = R.drawable.bg_experience
            )
        }
    }

    // --------------------------------------------------
    // POPUP EXPERIENCE PREVIEW (NEW)
    // --------------------------------------------------
    private fun openExperiencePreview(experience: PopularExperience) {

        val dialog = ExperiencePreviewDialogFragment.newInstance(
            title = experience.title,
            description = experience.subtitle
        )


        dialog.show(
            parentFragmentManager,
            "ExperiencePreviewDialog"
        )
    }

    // --------------------------------------------------
    // OLD NAVIGATION (NOT USED FOR NOW)
    // --------------------------------------------------
    private fun openDailyPlanPage(experience: PopularExperience) {
        val fragment = DailyPlanFragment.newInstance(experience.title)

        requireActivity()
            .supportFragmentManager
            .beginTransaction()
            .replace(R.id.contentContainer, fragment)
            .addToBackStack(null)
            .commit()
    }
}
