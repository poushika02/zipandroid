package com.example.habitbuilder.ui.home

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View

class WeekOrbitView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    // ----------------------------
    // PAINTS
    // ----------------------------

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 26f
        color = resolveThemeColor(android.R.attr.colorPrimary)
        alpha = 70                 // very soft background ring
        strokeCap = Paint.Cap.ROUND
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 30f
        strokeCap = Paint.Cap.ROUND
        color = resolveThemeColor(android.R.attr.colorPrimary)
        alpha = 180
        setShadowLayer(18f, 0f, 0f, color) // glow
    }

    init {
        // Needed for glow rendering
        setLayerType(LAYER_TYPE_SOFTWARE, glowPaint)
    }

    // ----------------------------
    // ANIMATION
    // ----------------------------

    private var sweepAngle = 34f          // length of glowing segment
    private var startAngle = 270f         // starts at bottom

    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 9000L                  // slow & calm
        repeatCount = ValueAnimator.INFINITE
        interpolator = null               // linear motion
        addUpdateListener {
            startAngle = 270f + it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    // ----------------------------
    // DRAWING
    // ----------------------------

    private val arcRect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val size = width.coerceAtMost(height).toFloat()
        val padding = 16f

        arcRect.set(
            padding,
            padding,
            size - padding,
            size - padding
        )

        // Static track
        canvas.drawArc(
            arcRect,
            0f,
            360f,
            false,
            trackPaint
        )

        // Moving glowing segment
        canvas.drawArc(
            arcRect,
            startAngle,
            sweepAngle,
            false,
            glowPaint
        )
    }

    // ----------------------------
    // THEME COLOR RESOLVER
    // ----------------------------

    private fun resolveThemeColor(attr: Int): Int {
        val typedValue = TypedValue()
        context.theme.resolveAttribute(attr, typedValue, true)
        return typedValue.data
    }
}
