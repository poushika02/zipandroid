package com.example.habitbuilder.ui.onboarding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.habitbuilder.R

class InterestsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(
            R.layout.fragment_onboarding_interests,
            container,
            false
        )

        val continueButton = view.findViewById<Button>(R.id.continue_button)
        val backButton = view.findViewById<TextView>(R.id.back_button)

        continueButton.setOnClickListener {
            val fragment = FearsFragment()
            val bundle = arguments ?: Bundle()

            // TODO replace with actual selected interests later
            bundle.putStringArrayList(
                "interests",
                arrayListOf("Fitness") // safe default
            )

            fragment.arguments = bundle

            parentFragmentManager.beginTransaction()
                .replace(R.id.onboarding_fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }

        backButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        return view
    }
}
