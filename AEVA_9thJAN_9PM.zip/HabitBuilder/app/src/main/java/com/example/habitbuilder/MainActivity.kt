package com.example.habitbuilder

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.habitbuilder.ui.ai.AiPromptDialogFragment
import com.example.habitbuilder.ui.home.HomeFragment
import com.example.habitbuilder.ui.login.LoginActivity
import com.example.habitbuilder.ui.playground.PlaygroundFragment
import com.example.habitbuilder.ui.progress.ProgressFragment
import com.example.habitbuilder.ui.profile.ProfileFragment
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.navigation.NavigationBarView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // ---------------- INITIAL FRAGMENT ----------------
        if (savedInstanceState == null) {
            val openFragment = intent.getStringExtra("openFragment")
            if (openFragment == "profile") {
                openFragment(ProfileFragment())
                findViewById<NavigationBarView>(R.id.bottomNav).selectedItemId =
                    R.id.nav_profile
            } else {
                openFragment(HomeFragment())
            }
        }

        // ---------------- TOP BAR : PROFILE CLICK ----------------
        findViewById<MaterialCardView>(R.id.btnProfile).setOnClickListener {
            showLogoutDialog()
        }

        // ---------------- BOTTOM NAV ----------------
        val bottomNav = findViewById<NavigationBarView>(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {

                // ✨ AI SPARKLE ACTION (NO FRAGMENT CHANGE)
                R.id.nav_aeva -> {
                    AiPromptDialogFragment()
                        .show(supportFragmentManager, "AiPrompt")
                    false // critical: keeps current tab selected
                }

                R.id.nav_home -> openFragment(HomeFragment())
                R.id.nav_profile -> openFragment(ProfileFragment())
                R.id.nav_progress -> openFragment(ProgressFragment())
                R.id.nav_playground -> openFragment(PlaygroundFragment())
            }
            true
        }
    }

    // ---------------- LOGOUT DIALOG ----------------
    private fun showLogoutDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to log out?")
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .setPositiveButton("Logout") { _, _ ->
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags =
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
            }
            .show()
    }

    // ---------------- TOP BAR CONTROLLER ----------------
    fun setTopBar(
        title: String,
        subtitle: String? = null,
        showNotification: Boolean = true,
        showProfile: Boolean = true
    ) {
        val tvTitle = findViewById<TextView>(R.id.tvAppName)
        val tvSubtitle = findViewById<TextView>(R.id.tvAppVersion)
        val btnNotification = findViewById<MaterialCardView>(R.id.btnNotification)
        val btnProfile = findViewById<MaterialCardView>(R.id.btnProfile)

        tvTitle.text = title

        if (subtitle != null) {
            tvSubtitle.text = subtitle
            tvSubtitle.visibility = View.VISIBLE
        } else {
            tvSubtitle.visibility = View.GONE
        }

        btnNotification.visibility =
            if (showNotification) View.VISIBLE else View.GONE
        btnProfile.visibility =
            if (showProfile) View.VISIBLE else View.GONE
    }

    // ---------------- FRAGMENT NAVIGATION ----------------
    private fun openFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.contentContainer, fragment)
            .commit()
    }
}
