package com.example.habitbuilder.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habitbuilder.data.model.TaskResponse
import com.example.habitbuilder.data.repository.TaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

class HomeViewModel : ViewModel() {

    private val repository = TaskRepository()

    private val _todayTasks =
        MutableStateFlow<List<TaskResponse>>(emptyList())

    val todayTasks: StateFlow<List<TaskResponse>> = _todayTasks

    fun loadTodayTasks(profileId: String) {
        viewModelScope.launch {
            val response = repository.getTasks(profileId)

            if (response.isSuccessful) {
                val allTasks = response.body() ?: emptyList()

                val today = Calendar.getInstance()
                    .get(Calendar.DAY_OF_WEEK)

                val backendDay = when (today) {
                    Calendar.MONDAY -> 1
                    Calendar.TUESDAY -> 2
                    Calendar.WEDNESDAY -> 3
                    Calendar.THURSDAY -> 4
                    Calendar.FRIDAY -> 5
                    Calendar.SATURDAY -> 6
                    Calendar.SUNDAY -> 7
                    else -> null
                }

                _todayTasks.value =
                    allTasks.filter {
                        it.dayOfWeek == backendDay
                    }
            }
        }
    }
}
