package com.example.habitbuilder.data.model

data class OnboardingResponse(
    val success: Boolean,
    val profileId: String
)
