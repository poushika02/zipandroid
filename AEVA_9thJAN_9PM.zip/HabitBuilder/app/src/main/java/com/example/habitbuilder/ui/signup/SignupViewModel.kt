package com.example.habitbuilder.ui.signup

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habitbuilder.data.model.SignupRequest
import com.example.habitbuilder.data.repository.AuthRepository
import kotlinx.coroutines.launch

class SignupViewModel : ViewModel() {

    private val repository = AuthRepository()

    fun register(
        name: String,
        email: String,
        password: String,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val response = repository.registerUser(
                    SignupRequest(name, email, password)
                )

                if (response.isSuccessful && response.body() != null) {
                    onSuccess(response.body()!!.verificationToken)
                } else {
                    onError("Signup failed (${response.code()})")
                }
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Network error")
            }
        }
    }
}
