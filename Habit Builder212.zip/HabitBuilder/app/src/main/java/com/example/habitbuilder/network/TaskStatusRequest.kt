package com.example.habitbuilder.network

/**
 * Request body for:
 * POST api/v1/task/{id}/status
 */
data class TaskStatusRequest(
    val status: String,          // "COMPLETED" or "NOT_COMPLETED"
    val score: Int? = 1,     // only for COMPLETED
    val feedback: String? = null   // only for NOT_COMPLETED
)
//"status": "COMPLETED",
//"score": 90,
//"feedback": "GOOD"