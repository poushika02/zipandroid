package com.example.habitbuilder.data.repository

import com.example.habitbuilder.data.model.GenerateWeekPlanRequest
import com.example.habitbuilder.network.AiApi
import com.example.habitbuilder.network.ApiClient
import retrofit2.Response

class AiRepository {

    private val aiApi: AiApi =
        ApiClient.createService(AiApi::class.java)

    // ✅ GENERIC – prompt comes from UI
    suspend fun generateWeekPlan(
        profileId: String,
        userPrompt: String
    ): Response<Unit> {
        return aiApi.generateWeekPlan(
            GenerateWeekPlanRequest(
                profileId = profileId,
                userPrompt = userPrompt
            )
        )
    }
}
