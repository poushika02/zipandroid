package com.example.habitbuilder.network

import com.example.habitbuilder.data.model.GenerateWeekPlanRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface AiApi {

    @POST("/api/v1/ai/ai/generate-week-plan")
    suspend fun generateWeekPlan(
        @Body request: GenerateWeekPlanRequest
    ): Response<Unit>
}
