//package com.example.habitbuilder.ui.home
//
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.TextView
//import androidx.recyclerview.widget.RecyclerView
//import com.example.habitbuilder.R
//import com.example.habitbuilder.data.model.TaskResponse
//
//class TodayTasksAdapter :
//    RecyclerView.Adapter<TodayTasksAdapter.TaskViewHolder>() {
//
//    private var tasks: List<TaskResponse> = emptyList()
//
//    fun submitList(newTasks: List<TaskResponse>) {
//        tasks = newTasks
//        notifyDataSetChanged()
//    }
//
//    override fun onCreateViewHolder(
//        parent: ViewGroup,
//        viewType: Int
//    ): TaskViewHolder {
//        val view = LayoutInflater.from(parent.context)
//            .inflate(R.layout.item_today_task, parent, false)
//        return TaskViewHolder(view)
//    }
//
//    override fun onBindViewHolder(
//        holder: TaskViewHolder,
//        position: Int
//    ) {
//        holder.bind(tasks[position])
//    }
//
//    override fun getItemCount(): Int = tasks.size
//
//    class TaskViewHolder(itemView: View)
//        : RecyclerView.ViewHolder(itemView) {
//
//        private val title =
//            itemView.findViewById<TextView>(R.id.taskTitle)
//
//        fun bind(task: TaskResponse) {
//            title.text = task.title
//        }
//    }
//}
package com.example.habitbuilder.ui.home

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.R
import com.example.habitbuilder.data.model.TaskResponse
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class TodayTasksAdapter(
    private val listener: TaskActionListener
) : RecyclerView.Adapter<TodayTasksAdapter.TaskViewHolder>() {

    private var tasks: List<TaskResponse> = emptyList()

    fun submitList(newTasks: List<TaskResponse>) {
        tasks = newTasks
        notifyDataSetChanged()
    }

    interface TaskActionListener {
        fun onTaskCompleted(task: TaskResponse, rating: Int)
        fun onTaskNotCompleted(task: TaskResponse, reason: String)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_today_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(tasks[position], listener)
    }

    override fun getItemCount(): Int = tasks.size

    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        // ---------- BASIC INFO ----------
        private val title: TextView =
            itemView.findViewById(R.id.tvTaskTitle)

        // ---------- ACTION BUTTONS ----------
        private val btnComplete: ImageView =
            itemView.findViewById(R.id.btnComplete)

        private val btnNotComplete: ImageView =
            itemView.findViewById(R.id.btnNotComplete)

        // ---------- EXPANDABLE ----------
        private val expandable: LinearLayout =
            itemView.findViewById(R.id.layoutExpandable)

        private val ratingBar: RatingBar =
            itemView.findViewById(R.id.ratingBar)

        private val reasonLayout: TextInputLayout =
            itemView.findViewById(R.id.reasonLayout)

        private val etReason: TextInputEditText =
            itemView.findViewById(R.id.etReason)

        private val btnSend: MaterialButton =
            itemView.findViewById(R.id.btnSend)

        fun bind(task: TaskResponse, listener: TaskActionListener) {
            Log.d("API_FLOW", "bind() called for task=${task.id}")
            title.text = task.title

            // ✔ COMPLETE
            btnComplete.setOnClickListener {
                expandable.visibility = View.VISIBLE
                ratingBar.visibility = View.VISIBLE
                reasonLayout.visibility = View.GONE
                btnSend.visibility = View.VISIBLE
            }

            // ✖ NOT COMPLETE
            btnNotComplete.setOnClickListener {
                expandable.visibility = View.VISIBLE
                ratingBar.visibility = View.GONE
                reasonLayout.visibility = View.VISIBLE
                btnSend.visibility = View.VISIBLE
            }

            // 📤 SEND → notify Fragment
            btnSend.setOnClickListener {
                Log.d("API_FLOW", "📤 Send clicked in Adapter for task=${task.id}")

                if (ratingBar.visibility == View.VISIBLE) {
                    Log.d("API_FLOW", "Mode=COMPLETED rating=${ratingBar.rating}")
                    listener.onTaskCompleted(task, ratingBar.rating.toInt())
                } else {
                    Log.d("API_FLOW", "Mode=NOT_COMPLETED reason=${etReason.text}")
                    listener.onTaskNotCompleted(task, etReason.text.toString())
                }
            }

        }
    }
}
