package com.example.habitbuilder.data.repository

import com.example.habitbuilder.network.ApiClient
import com.example.habitbuilder.network.TaskApi
import com.example.habitbuilder.network.TaskStatusRequest

class TaskRepository {

    private val api =
        ApiClient.createService(TaskApi::class.java)

    suspend fun getTasks(profileId: String) =
        api.getTasksByProfile(profileId)

    // ✅ NEW: UPDATE TASK STATUS
    suspend fun updateTaskStatus(
        taskId: String,
        status: String,
        score: Int? = null,
        feedback: String? = null
    ) =
        api.updateTaskStatus(
            taskId,
            TaskStatusRequest(
                status = status,
                score = score,
                feedback = feedback
            )
        )
}
