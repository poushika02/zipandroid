package com.example.habitbuilder
// 👈 MUST match your package

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView


class ProgressCardAdapter :
    RecyclerView.Adapter<ProgressCardAdapter.CardViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_swipe_card, parent, false)
        return CardViewHolder(view)
    }

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {}

    override fun getItemCount(): Int = 3

    class CardViewHolder(view: View) : RecyclerView.ViewHolder(view)
}
