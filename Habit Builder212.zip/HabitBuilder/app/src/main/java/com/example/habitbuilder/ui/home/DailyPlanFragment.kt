package com.example.habitbuilder.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.R

class DailyPlanFragment : Fragment() {

    private var experienceTitle: String? = null
    private lateinit var recyclerView: RecyclerView

    // --------------------------------------------------
    // LIFECYCLE
    // --------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        experienceTitle = arguments?.getString(ARG_EXPERIENCE_TITLE)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_daily_plan, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.rvDailyTasks)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        recyclerView.adapter = DailyTaskAdapter(
            tasks = getDummyTasks(),
            listener = object : DailyTaskAdapter.TaskActionListener {

                override fun onTaskCompleted(task: DailyTask, rating: Int) {
                    val score = rating * 20
                    // API call later
                }

                override fun onTaskNotCompleted(task: DailyTask, reason: String) {
                    // API call later
                }
            }
        )

    }

    // --------------------------------------------------
    // DUMMY DATA (FIXED)
    // --------------------------------------------------
    private fun getDummyTasks(): List<DailyTask> {
        return listOf(
            DailyTask(
                id = "dummy_task_1",
                title = "Walking 5km",
                description = "",
                scheduledStart = "17:00",
                scheduledEnd = "18:00",
                dayOfWeek = 1,
                status = "PENDING"
            ),
            DailyTask(
                id = "dummy_task_2",
                title = "Meditation",
                description = "",
                scheduledStart = "07:00",
                scheduledEnd = "07:15",
                dayOfWeek = 1,
                status = "PENDING"
            )
        )
    }

    // --------------------------------------------------
    // FACTORY METHOD
    // --------------------------------------------------
    companion object {

        private const val ARG_EXPERIENCE_TITLE = "arg_experience_title"

        fun newInstance(experienceTitle: String): DailyPlanFragment {
            return DailyPlanFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_EXPERIENCE_TITLE, experienceTitle)
                }
            }
        }
    }
}

