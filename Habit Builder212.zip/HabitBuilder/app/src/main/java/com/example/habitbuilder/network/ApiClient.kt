//package com.example.habitbuilder.network
//
//import okhttp3.OkHttpClient
//import okhttp3.logging.HttpLoggingInterceptor
//import retrofit2.Retrofit
//import retrofit2.converter.gson.GsonConverterFactory
//import com.example.habitbuilder.HabitBuilderApp
//import java.util.concurrent.TimeUnit
//
//object ApiClient {
//
//    // TODO replace with your actual AWS backend URL
//    private const val BASE_URL = "http://10.0.2.2:3000/"
//
//    private val loggingInterceptor = HttpLoggingInterceptor().apply {
//        level = HttpLoggingInterceptor.Level.BODY
//    }
//
//    private val okHttpClient: OkHttpClient by lazy {
//        OkHttpClient.Builder()
//            .connectTimeout(300, TimeUnit.SECONDS)
//            .readTimeout(300, TimeUnit.SECONDS)
//            .writeTimeout(300, TimeUnit.SECONDS)
//            .addInterceptor(AuthInterceptor(HabitBuilderApp.appContext))
//            .addInterceptor(loggingInterceptor)
//            .addInterceptor(loggingInterceptor)
//            .build()
//    }
//
//    private val retrofit: Retrofit by lazy {
//        Retrofit.Builder()
//            .baseUrl(BASE_URL)
//            .client(okHttpClient)
//            .addConverterFactory(GsonConverterFactory.create())
//            .build()
//    }
//
//    fun <T> createService(serviceClass: Class<T>): T {
//        return retrofit.create(serviceClass)
//    }
//}
package com.example.habitbuilder.network

import android.util.Log
import com.example.habitbuilder.HabitBuilderApp
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {
    init {
        Log.d("API_FLOW", "ApiClient initialized with BASE_URL=$BASE_URL")
    }


    // Emulator → localhost
    private const val BASE_URL = "http://aeva-alb-713642318.ap-south-1.elb.amazonaws.com/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(300, TimeUnit.SECONDS)
            .readTimeout(300, TimeUnit.SECONDS)
            .writeTimeout(300, TimeUnit.SECONDS)
            .addInterceptor(AuthInterceptor(HabitBuilderApp.appContext))
            .addInterceptor(loggingInterceptor) // ✅ only once
            .build()
    }

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    /** Generic creator (still usable if needed) */
    fun <T> createService(serviceClass: Class<T>): T {
        return retrofit.create(serviceClass)
    }

    /** ✅ Concrete API used by Adapter / ViewModel */
    val taskApi: TaskApi by lazy {
        retrofit.create(TaskApi::class.java)
    }
}
