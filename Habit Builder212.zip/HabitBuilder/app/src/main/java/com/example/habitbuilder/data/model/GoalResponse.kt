package com.example.habitbuilder.data.model

data class GoalResponse(
    val id: String,
    val profileId: String,
    val title: String,
    val description: String?,
    val status: String,
    val createdAt: String,
    val plannedWeeks: Int,
    val metadata: Any?,
    val correlationId: String?,
    val plans: List<PlanResponse>
)
