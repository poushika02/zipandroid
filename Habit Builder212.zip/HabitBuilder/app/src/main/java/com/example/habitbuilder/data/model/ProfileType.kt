package com.example.habitbuilder.data.model

enum class ProfileType {
    CHILD,
    ADULT,
    PARENT,
    PARTNER,
    ELDER,
    STUDENT,
    ATHLETE
}
