package com.example.habitbuilder.ui.onboarding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.habitbuilder.R
import com.example.habitbuilder.data.model.ProfileType
import com.google.android.material.card.MaterialCardView

class ProfileTypeFragment : Fragment() {

    // 🔐 BACKEND SAFE ENUM (default)
    private var selectedProfileType: ProfileType = ProfileType.ADULT

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_onboarding_profile_type, container, false)

        val cardSelf = view.findViewById<MaterialCardView>(R.id.cardSelf)
        val cardSomeoneElse = view.findViewById<MaterialCardView>(R.id.cardSomeoneElse)
        val continueButton = view.findViewById<Button>(R.id.continueButton)
        val backButton = view.findViewById<TextView>(R.id.backText)

        // Default selection → SELF = ADULT
        cardSelf.strokeWidth = 2
        cardSomeoneElse.strokeWidth = 0

        cardSelf.setOnClickListener {
            // Self → ADULT
            selectedProfileType = ProfileType.ADULT
            cardSelf.strokeWidth = 2
            cardSomeoneElse.strokeWidth = 0
        }

        cardSomeoneElse.setOnClickListener {
            // Someone else → CHILD (you can later refine this)
            selectedProfileType = ProfileType.CHILD
            cardSelf.strokeWidth = 0
            cardSomeoneElse.strokeWidth = 2
        }

        continueButton.setOnClickListener {
            val fragment = UserDetailsFragment()
            val bundle = Bundle()

            // 🔥 PASS ENUM NAME (EXACT MATCH WITH PRISMA)
            bundle.putString("profileType", selectedProfileType.name)

            fragment.arguments = bundle

            parentFragmentManager.beginTransaction()
                .replace(R.id.onboarding_fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }

        backButton.setOnClickListener {
            activity?.finish()
        }

        return view
    }
}
