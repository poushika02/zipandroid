package com.example.habitbuilder.data.local

import android.content.Context

class UserPrefs(context: Context) {

    private val prefs =
        context.getSharedPreferences("habit_prefs", Context.MODE_PRIVATE)

    fun saveProfileId(profileId: String) {
        prefs.edit()
            .putString(KEY_PROFILE_ID, profileId)
            .apply()
    }

    fun getProfileId(): String? {
        return prefs.getString(KEY_PROFILE_ID, null)
    }

    companion object {
        private const val KEY_PROFILE_ID = "profile_id"
    }
}
