package com.example.habitbuilder.ui.onboarding

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.habitbuilder.MainActivity
import com.example.habitbuilder.R
import com.example.habitbuilder.data.local.UserPrefs
import com.example.habitbuilder.data.model.BasicInfo
import com.example.habitbuilder.data.model.OnboardingRequest
import com.example.habitbuilder.data.repository.AiRepository
import com.example.habitbuilder.data.repository.OnboardingRepository
import kotlinx.coroutines.launch

class OnboardingCompleteFragment : Fragment() {

    private val onboardingRepository = OnboardingRepository()
    private val aiRepository = AiRepository()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(
            R.layout.fragment_onboarding_complete,
            container,
            false
        )

        val getStartedButton =
            view.findViewById<Button>(R.id.getStartedButton)
        val backButton =
            view.findViewById<TextView>(R.id.back_button)
        val titleText =
            view.findViewById<TextView>(R.id.title)

        val userName =
            arguments?.getString("userName") ?: ""

        val profileType =
            arguments?.getString("profileType") ?: "ADULT"

        val gender =
            arguments?.getString("gender") ?: "OTHER"

        val age =
            arguments?.getInt("age")

        val challenges =
            arguments?.getStringArrayList("challenges")
                ?: emptyList()

        val interests =
            arguments?.getStringArrayList("interests")
                ?: emptyList()

        titleText.text = "You're all set, $userName"

        getStartedButton.setOnClickListener {
            submitOnboarding(
                userName = userName,
                age = age,
                gender = gender,
                profileType = profileType,
                challenges = challenges,
                interests = interests
            )
        }

        backButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        return view
    }

    // --------------------------------------------------
    // ONBOARDING → SAVE PROFILE → TRIGGER AI → HOME
    // --------------------------------------------------
    private fun submitOnboarding(
        userName: String,
        age: Int?,
        gender: String,
        profileType: String,
        challenges: List<String>,
        interests: List<String>
    ) {
        lifecycleScope.launch {
            try {
                val request = OnboardingRequest(
                    basicInfo = BasicInfo(
                        name = userName,
                        age = age,
                        gender = gender,
                        type = profileType
                    ),
                    challenges = challenges,
                    interests = interests,
                    availability = emptyMap()
                )

                val response =
                    onboardingRepository.submitOnboarding(request)

                if (!response.isSuccessful || response.body() == null) {
                    Toast.makeText(
                        requireContext(),
                        "Onboarding failed (${response.code()})",
                        Toast.LENGTH_LONG
                    ).show()
                    return@launch
                }

                val profileId =
                    response.body()!!.profileId

                // ✅ CRITICAL FIX: persist profileId for first login & restarts
                UserPrefs(requireContext()).saveProfileId(profileId)

                // ✅ SINGLE-PARAGRAPH SAFE PROMPT
                val prompt = buildWalkingHabitPrompt()

                val aiResponse =
                    aiRepository.generateWeekPlan(
                        profileId = profileId,
                        userPrompt = prompt
                    )

                if (!aiResponse.isSuccessful) {
                    Toast.makeText(
                        requireContext(),
                        "Failed to generate habit plan",
                        Toast.LENGTH_LONG
                    ).show()
                    return@launch
                }

                // ✅ NAVIGATE TO MAIN / HOME
                val intent = Intent(
                    requireActivity(),
                    MainActivity::class.java
                )
                intent.flags =
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    // --------------------------------------------------
    // SINGLE-PARAGRAPH PROMPT (BACKEND SAFE)
    // --------------------------------------------------
    private fun buildWalkingHabitPrompt(): String {
        return "Act as a habit-building coach and create a 4-week walking habit plan for a beginner. The plan should focus on natural, gradual progression and consistency rather than intensity, starting with very easy and achievable walks and increasing the duration or frequency slightly each week without sudden jumps. Include 5 to 6 walking days per week with 1 to 2 light or rest days. For each week, clearly mention the daily walking time and add a brief, encouraging guidance. Use simple, friendly, and motivating language, avoid medical or extreme fitness advice, and end with a short motivational note about staying consistent."
    }
}
