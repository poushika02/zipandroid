package com.example.habitbuilder.ui.home

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.MainActivity
import com.example.habitbuilder.R
import com.example.habitbuilder.data.local.UserPrefs
import com.example.habitbuilder.data.repository.GoalRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private val goalRepository = GoalRepository()
    private lateinit var adapter: PopularExperienceAdapter
    private var profileId: String? = null

    // Polling control
    private var pollingJob: Job? = null
    private var isPolling = false

    // --------------------------------------------------
    // LIFECYCLE
    // --------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ✅ Single source of truth for profileId
        profileId = UserPrefs(requireContext()).getProfileId()
        Log.d("HomeFragment", "Loaded profileId = $profileId")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_homepage, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // --------------------------------------------------
        // HERO TITLE (USER NAME)
        // --------------------------------------------------
        val heroTitleView =
            view.findViewById<TextView>(R.id.tvHeroTitle)

        val namePrefs =
            requireContext().getSharedPreferences(
                "auth_prefs",
                Context.MODE_PRIVATE
            )

        val userName =
            namePrefs.getString("profile_name", null)

        heroTitleView.text =
            if (!userName.isNullOrBlank()) {
                "$userName’s Experiences"
            } else {
                "My Experiences"
            }

        // --------------------------------------------------
        // GOAL TITLE + DESCRIPTION
        // --------------------------------------------------
        val goalTitleText =
            view.findViewById<TextView>(R.id.tvPopularTitle)
        val goalDescriptionText =
            view.findViewById<TextView>(R.id.tvGoalDescription)

        // --------------------------------------------------
        // RECYCLER VIEW (ATTACH ADAPTER IMMEDIATELY)
        // --------------------------------------------------
        val recyclerView =
            view.findViewById<RecyclerView>(R.id.rvPopularExperiences)

        recyclerView.layoutManager =
            LinearLayoutManager(
                requireContext(),
                LinearLayoutManager.HORIZONTAL,
                false
            )

        adapter = PopularExperienceAdapter(emptyList()) {
            openExperiencePreview(it)
        }
        recyclerView.adapter = adapter

        if (profileId == null) {
            showPlaceholderGoal(goalTitleText, goalDescriptionText)
            startPolling(null, goalTitleText, goalDescriptionText)
            return
        }

        fetchGoals(profileId!!, goalTitleText, goalDescriptionText)
    }

    override fun onResume() {
        super.onResume()
        val activity = activity as? MainActivity ?: return
        activity.setTopBar(
            title = "My Habits",
            subtitle = "Your daily progress"
        )
    }

    override fun onStop() {
        super.onStop()
        stopPolling()
    }

    // --------------------------------------------------
    // CORE LOGIC: FETCH + DECIDE + POLL
    // --------------------------------------------------
    private fun fetchGoals(
        profileId: String,
        titleView: TextView,
        descriptionView: TextView
    ) {
        lifecycleScope.launch {
            try {
                Log.d(
                    "HomeFragment",
                    "Fetching goals for profileId=$profileId"
                )

                val response =
                    goalRepository.getGoalsByProfile(profileId)

                if (!response.isSuccessful) {
                    showPlaceholderGoal(titleView, descriptionView)
                    startPolling(profileId, titleView, descriptionView)
                    return@launch
                }

                val goals = response.body().orEmpty()

                // -----------------------------
                // STATE 1: NO GOAL YET
                // -----------------------------
                if (goals.isEmpty()) {
                    showPlaceholderGoal(titleView, descriptionView)
                    startPolling(profileId, titleView, descriptionView)
                    return@launch
                }

                val goal = goals.first()

                val isReady =
                    !goal.title.isNullOrBlank() ||
                            (goal.plannedWeeks != null && goal.plannedWeeks > 0)

                // -----------------------------
                // STATE 2: GOAL EXISTS BUT PENDING
                // -----------------------------
                if (!isReady) {
                    showPlaceholderGoal(titleView, descriptionView)
                    startPolling(profileId, titleView, descriptionView)
                    return@launch
                }

                // -----------------------------
                // STATE 3: GOAL READY
                // -----------------------------
                stopPolling()

                val title =
                    goal.title ?: "Your Habit Plan"

                val description =
                    goal.description ?: "Your personalized plan is ready"

                val plannedWeeks =
                    goal.plannedWeeks ?: 1

                titleView.text = title
                descriptionView.text = description

                val weekCards =
                    generateWeekCards(plannedWeeks)

                adapter.updateData(weekCards)

            } catch (e: Exception) {
                Log.e("HomeFragment", "Error fetching goals", e)
                showPlaceholderGoal(titleView, descriptionView)
                startPolling(profileId, titleView, descriptionView)
            }
        }
    }

    // --------------------------------------------------
    // POLLING CONTROL
    // --------------------------------------------------
    private fun startPolling(
        profileId: String?,
        titleView: TextView,
        descriptionView: TextView
    ) {
        if (isPolling || profileId == null) return

        isPolling = true
        pollingJob = lifecycleScope.launch {
            while (isPolling) {
                delay(10_000) // 10 seconds
                Log.d(
                    "HomeFragment",
                    "Polling for goal persistence..."
                )
                fetchGoals(profileId, titleView, descriptionView)
            }
        }
    }

    private fun stopPolling() {
        isPolling = false
        pollingJob?.cancel()
        pollingJob = null
    }

    // --------------------------------------------------
    // PLACEHOLDER GOAL (EMPTY + PENDING)
    // --------------------------------------------------
    private fun showPlaceholderGoal(
        titleView: TextView,
        descriptionView: TextView
    ) {
        titleView.text = "Your Habit Plan"
        descriptionView.text =
            "We’re creating your personalized plan. This may take a moment."

        val placeholderWeeks =
            generateWeekCards(1)

        adapter.updateData(placeholderWeeks)
    }

    // --------------------------------------------------
    // WEEK CARD GENERATOR
    // --------------------------------------------------
    private fun generateWeekCards(
        plannedWeeks: Int
    ): List<PopularExperience> {
        return (1..plannedWeeks).map { week ->
            PopularExperience(
                title = "Week $week",
                subtitle = "Your plan for week $week",
                imageRes = R.drawable.bg_experience
            )
        }
    }

    // --------------------------------------------------
    // EXPERIENCE PREVIEW
    // --------------------------------------------------
    private fun openExperiencePreview(
        experience: PopularExperience
    ) {
        val dialog =
            ExperiencePreviewDialogFragment.newInstance(
                title = experience.title,
                description = experience.subtitle
            )

        dialog.show(
            parentFragmentManager,
            "ExperiencePreviewDialog"
        )
    }
}
