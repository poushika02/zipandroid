package com.example.habitbuilder.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.R

class PopularExperienceAdapter(
    private var items: List<PopularExperience>,
    private val onItemClick: (PopularExperience) -> Unit
) : RecyclerView.Adapter<PopularExperienceAdapter.ExperienceViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ExperienceViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_popular_experience, parent, false)
        return ExperienceViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: ExperienceViewHolder,
        position: Int
    ) {
        val item = items[position]
        holder.bind(item)
        holder.itemView.setOnClickListener {
            onItemClick(item)
        }
    }

    override fun getItemCount(): Int = items.size

    // --------------------------------------------------
    // 🔥 CRITICAL FIX: allow data updates
    // --------------------------------------------------
    fun updateData(newItems: List<PopularExperience>) {
        items = newItems
        notifyDataSetChanged()
    }

    class ExperienceViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        private val tvTitle: TextView =
            itemView.findViewById(R.id.tvExperienceTitle)

        private val tvSubtitle: TextView =
            itemView.findViewById(R.id.tvExperienceSubtitle)

        fun bind(item: PopularExperience) {
            tvTitle.text = item.title
            tvSubtitle.text = item.subtitle
        }
    }
}
