//package com.example.habitbuilder.network
//
//import com.example.habitbuilder.data.model.TaskResponse
//import retrofit2.Response
//import retrofit2.http.GET
//import retrofit2.http.Path
//
//interface TaskApi {
//
//    @GET("/api/v1/task/profile/{profileId}")
//    suspend fun getTasksByProfile(
//        @Path("profileId") profileId: String
//    ): Response<List<TaskResponse>>
//}
package com.example.habitbuilder.network

import com.example.habitbuilder.data.model.TaskResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path

interface TaskApi {

    @GET("api/v1/task/profile/{profileId}")
    suspend fun getTasksByProfile(
        @Path("profileId") profileId: String
    ): Response<List<TaskResponse>>

    @PATCH("api/v1/task/{taskId}/status")
    suspend fun updateTaskStatus(
        @Path("taskId") taskId: String,
        @Body body: TaskStatusRequest
    ): Response<Unit>

}

/**
 * Unified request body
 */

