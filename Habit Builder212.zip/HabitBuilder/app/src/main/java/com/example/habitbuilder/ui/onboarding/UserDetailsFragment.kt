package com.example.habitbuilder.ui.onboarding

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.habitbuilder.R
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.textfield.TextInputEditText

class UserDetailsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(
            R.layout.fragment_onboarding_user_details,
            container,
            false
        )

        val nameInput = view.findViewById<TextInputEditText>(R.id.nameInput)
        val ageInput = view.findViewById<TextInputEditText>(R.id.ageInput)
        val genderChipGroup = view.findViewById<ChipGroup>(R.id.genderChipGroup)
        val continueButton = view.findViewById<Button>(R.id.continueButton)
        val backButton = view.findViewById<TextView>(R.id.back_button)

        continueButton.isEnabled = false

        nameInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                continueButton.isEnabled = !s.isNullOrBlank()
            }
        })

        continueButton.setOnClickListener {
            val fragment = InterestsFragment()
            val bundle = arguments ?: Bundle()

            val name = nameInput.text?.toString()?.trim().orEmpty()
            val age = ageInput.text?.toString()?.toIntOrNull() ?: 0
            val gender = getSelectedGender(genderChipGroup)

            bundle.putString("userName", name)
            bundle.putInt("age", age)
            bundle.putString("gender", gender)

            fragment.arguments = bundle

            parentFragmentManager.beginTransaction()
                .replace(R.id.onboarding_fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }

        backButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        return view
    }

    private fun getSelectedGender(group: ChipGroup): String {
        val checkedId = group.checkedChipId
        if (checkedId == View.NO_ID) return "OTHER"

        val chip = group.findViewById<Chip>(checkedId)
        return chip.text.toString().uppercase() // MALE / FEMALE / OTHER
    }
}
