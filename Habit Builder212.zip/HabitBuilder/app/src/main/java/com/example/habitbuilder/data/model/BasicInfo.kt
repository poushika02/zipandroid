package com.example.habitbuilder.data.model

data class BasicInfo(
    val name: String,
    val age: Int?,
    val gender: String,   // "MALE" | "FEMALE" | "OTHER"
    val type: String      // "ADULT" | "CHILD" | ...
)
