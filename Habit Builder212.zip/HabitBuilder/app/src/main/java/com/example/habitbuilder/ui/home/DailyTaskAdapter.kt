package com.example.habitbuilder.ui.home

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.R
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class DailyTaskAdapter(
    private val tasks: List<DailyTask>,
    private val listener: TaskActionListener
) : RecyclerView.Adapter<DailyTaskAdapter.VH>() {

    private var expandedPos: Int? = null
    private var mode: Mode? = null

    enum class Mode { COMPLETE, NOT_COMPLETE }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_daily_task, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(tasks[position], position)
    }

    override fun getItemCount() = tasks.size

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {

        private val title = view.findViewById<TextView>(R.id.tvTaskTitle)
        private val time = view.findViewById<TextView>(R.id.tvTaskTime)
        private val day = view.findViewById<TextView>(R.id.tvTaskDay)

        private var selectedRating: Int = 0

        private val btnComplete = view.findViewById<ImageView>(R.id.btnComplete)
        private val btnNot = view.findViewById<ImageView>(R.id.btnNotComplete)

        private val expandable = view.findViewById<View>(R.id.layoutExpandable)
        private val ratingBar = view.findViewById<RatingBar>(R.id.ratingBar)
        private val reasonLayout = view.findViewById<TextInputLayout>(R.id.reasonLayout)
        private val reasonEdit = view.findViewById<TextInputEditText>(R.id.etReason)
        private val sendBtn = view.findViewById<MaterialButton>(R.id.btnSend)
        private val doneText = view.findViewById<TextView>(R.id.tvDone)

        fun bind(task: DailyTask, pos: Int) {

            title.text = task.title
            time.text = "${task.scheduledStart} - ${task.scheduledEnd}"
            day.text = "Day ${task.dayOfWeek}"

            val expanded = expandedPos == pos
            expandable.visibility = if (expanded) View.VISIBLE else View.GONE

            ratingBar.visibility =
                if (expanded && mode == Mode.COMPLETE) View.VISIBLE else View.GONE

            reasonLayout.visibility =
                if (expanded && mode == Mode.NOT_COMPLETE) View.VISIBLE else View.GONE

            // reset state (important for RecyclerView)
            sendBtn.visibility = View.GONE
            doneText.visibility = View.GONE

            // ⭐ RATING FLOW
            ratingBar.setOnRatingBarChangeListener { _, rating, fromUser ->
                if (fromUser && rating > 0 && mode == Mode.COMPLETE) {
                    selectedRating = rating.toInt()
                    sendBtn.visibility = View.VISIBLE
                }
            }


            // ❓ REASON FLOW
            reasonEdit.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (mode == Mode.NOT_COMPLETE) {
                        sendBtn.visibility =
                            if (!s.isNullOrBlank()) View.VISIBLE else View.GONE
                    }
                }
                override fun beforeTextChanged(s: CharSequence?, start: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, b: Int, c: Int) {}
            })

            // SEND (shared)
            sendBtn.setOnClickListener {
                sendBtn.visibility = View.GONE
                ratingBar.isEnabled = false
                reasonEdit.isEnabled = false
                doneText.visibility = View.VISIBLE

//                if (mode == Mode.COMPLETE) {
//                    listener.onTaskCompleted(task)
//                } else {
//                    listener.onTaskNotCompleted(task)
//                }
                if (mode == Mode.COMPLETE) {
                    listener.onTaskCompleted(task, selectedRating)
                } else {
                    listener.onTaskNotCompleted(task, reasonEdit.text.toString())
                }

            }

            btnComplete.setOnClickListener {
                toggle(pos, Mode.COMPLETE)
            }

            btnNot.setOnClickListener {
                toggle(pos, Mode.NOT_COMPLETE)
            }
        }
    }

    private fun toggle(pos: Int, newMode: Mode) {
        val old = expandedPos
        expandedPos = if (expandedPos == pos && mode == newMode) null else pos
        mode = newMode
        old?.let { notifyItemChanged(it) }
        notifyItemChanged(pos)
    }

    interface TaskActionListener {
        fun onTaskCompleted(task: DailyTask, rating: Int)
        fun onTaskNotCompleted(task: DailyTask, reason: String)
    }
}
