package com.example.habitbuilder

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.habitbuilder.ui.onboarding.ProfileTypeFragment
import com.example.habitbuilder.R


class OnboardingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.onboarding_fragment_container, ProfileTypeFragment())
                .commit()
        }
    }
}