package com.example.habitbuilder.ui.home

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.MainActivity
import com.example.habitbuilder.R
import com.example.habitbuilder.data.local.UserPrefs
import com.example.habitbuilder.data.repository.GoalRepository
import com.example.habitbuilder.data.repository.TaskRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.example.habitbuilder.data.repository.ProfileRepository


class HomeFragment : Fragment() {

    companion object {
        private const val TAG = "HomeFragment"
    }

    private val goalRepository = GoalRepository()
    private val taskRepository = TaskRepository()
    private val profileRepository = ProfileRepository()

    private lateinit var adapter: PopularExperienceAdapter
    private var profileId: String? = null

    private var pollingJob: Job? = null
    private var isPolling = false

    // --------------------------------------------------
    // LIFECYCLE
    // --------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        profileId = UserPrefs(requireContext()).getProfileId()
        Log.d(TAG, "onCreate → profileId=$profileId")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View =
        inflater.inflate(R.layout.fragment_homepage, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        Log.d(TAG, "onViewCreated")

        val heroTitleView = view.findViewById<TextView>(R.id.tvHeroTitle)
        val goalTitle = view.findViewById<TextView>(R.id.tvPopularTitle)
        val goalDesc = view.findViewById<TextView>(R.id.tvGoalDescription)

        heroTitleView.text =
            requireContext()
                .getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)
                .getString("profile_name", "My") + "’s Experiences"

        val recyclerView =
            view.findViewById<RecyclerView>(R.id.rvPopularExperiences)

        recyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)

        adapter = PopularExperienceAdapter(emptyList()) {
            Log.d(TAG, "Week card clicked → week=${it.weekNumber}")
            openExperiencePreview(it)
        }
        recyclerView.adapter = adapter

        // 🔑 Initial load (login-safe)
        profileId?.let {
            Log.d(TAG, "Initial fetchGoals()")
            fetchGoals(it, goalTitle, goalDesc)
        } ?: Log.e(TAG, "profileId is NULL on first load")

        // 🔔 LISTEN FOR TASK PATCH SUCCESS (popup-safe)
        parentFragmentManager.setFragmentResultListener(
            "task_status_updated",
            viewLifecycleOwner
        ) { _, _ ->
            Log.d(TAG, "Task PATCH success → refreshing completion %")

            val pid = UserPrefs(requireContext()).getProfileId()
                ?: return@setFragmentResultListener

            fetchGoals(pid, goalTitle, goalDesc)
        }
        requireActivity()
            .supportFragmentManager
            .setFragmentResultListener(
                "task_status_updated",
                viewLifecycleOwner
            ) { _, _ ->
                Log.d(TAG, "✅ Received task_status_updated")

                val pid = UserPrefs(requireContext()).getProfileId()
                    ?: return@setFragmentResultListener

                val goalTitle =
                    requireView().findViewById<TextView>(R.id.tvPopularTitle)
                val goalDesc =
                    requireView().findViewById<TextView>(R.id.tvGoalDescription)

                fetchGoals(pid, goalTitle, goalDesc)
            }

    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume")

        (activity as? MainActivity)?.setTopBar(
            title = "AEVA",
            subtitle = "Progress, together."
        )
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop → cancelling polling")
        pollingJob?.cancel()
        pollingJob = null
        isPolling = false
    }

    private suspend fun fetchAndSaveProfileIfMissing() {
        val prefs = UserPrefs(requireContext())

        if (!prefs.getProfileName().isNullOrBlank()) return

        val res = profileRepository.getAllProfiles()
        if (!res.isSuccessful) {
            Log.e(TAG, "Failed to fetch profiles")
            return
        }

        val profiles = res.body().orEmpty()

        val profile = profiles.firstOrNull {
            !it.name.isNullOrBlank() && !it.id.isNullOrBlank()
        } ?: run {
            Log.w(TAG, "No valid profile yet")
            return
        }

        prefs.saveProfileName(profile.name!!)
        prefs.saveProfileId(profile.id!!)

        Log.d(TAG, "✅ Profile saved: ${profile.name}")
    }


    // --------------------------------------------------
// HERO TITLE
// --------------------------------------------------
    private fun updateHeroTitle() {
        val name =
            UserPrefs(requireContext()).getProfileName()
                ?: requireContext()
                    .getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)
                    .getString("profile_name", null)

        val heroTitleView =
            requireView().findViewById<TextView>(R.id.tvHeroTitle)

        heroTitleView.text =
            if (!name.isNullOrBlank()) {
                "$name’s Experiences"
            } else {
                "My Experiences"
            }
    }

    // --------------------------------------------------
    // CORE LOGIC
    // --------------------------------------------------
    private fun fetchGoals(
        profileId: String,
        titleView: TextView,
        descView: TextView
    ) {
        Log.d(TAG, "fetchGoals(profileId=$profileId)")

        lifecycleScope.launch {
            val res = goalRepository.getGoalsByProfile(profileId)

            if (!res.isSuccessful) {
                Log.e(TAG, "Goals API FAILED → ${res.code()}")
                showPlaceholder(titleView, descView)
                startPolling(profileId, titleView, descView)
                return@launch
            }

            val goals = res.body().orEmpty()
            Log.d(TAG, "Goals fetched → count=${goals.size}")

            val goal = goals.firstOrNull()

            // FIRST TIME USER
            if (goal == null) {
                showPlaceholder(titleView, descView)
                startPolling(profileId, titleView, descView)
                return@launch
            }

            val weeks = goal.plannedWeeks ?: 1

            if (goal.title.isNullOrBlank() && weeks == 0) {
                showPlaceholder(titleView, descView)
                startPolling(profileId, titleView, descView)
                return@launch
            }

            stopPolling()


            fetchAndSaveProfileIfMissing()
            updateHeroTitle()
            titleView.text = goal.title ?: "Your Habit Plan"
            descView.text = goal.description ?: ""

            val completionMap =
                fetchCompletionPercentByWeek(profileId)

            val cards =
                (1..weeks).map { week ->
                    PopularExperience(
                        weekNumber = week,
                        title = "Week $week",
                        subtitle = "Your plan for week $week",
                        imageRes = R.drawable.bg_experience,
                        completionPercent = completionMap[week] ?: 0
                    )
                }

            adapter.updateData(cards)
        }
    }

    // --------------------------------------------------
    // PLACEHOLDER
    // --------------------------------------------------
    private fun showPlaceholder(
        titleView: TextView,
        descView: TextView
    ) {
        titleView.text = "Your Habit Plan"
        descView.text =
            "We’re creating your personalized plan. This may take a moment."

        adapter.updateData(
            listOf(
                PopularExperience(
                    weekNumber = 1,
                    title = "Week 1",
                    subtitle = "Your plan is being prepared",
                    imageRes = R.drawable.bg_experience,
                    completionPercent = 0
                )
            )
        )
    }

    // --------------------------------------------------
    // POLLING (unchanged)
    // --------------------------------------------------
    private fun startPolling(
        profileId: String,
        titleView: TextView,
        descView: TextView
    ) {
        if (isPolling) return

        isPolling = true
        pollingJob = lifecycleScope.launch {
            while (isPolling) {
                delay(5_000)
                fetchGoals(profileId, titleView, descView)
            }
        }
    }

    private fun stopPolling() {
        isPolling = false
        pollingJob?.cancel()
        pollingJob = null
    }

    // --------------------------------------------------
    // COMPLETION %
    // --------------------------------------------------
    private suspend fun fetchCompletionPercentByWeek(
        profileId: String
    ): Map<Int, Int> {

        val res = taskRepository.getTasks(profileId)
        if (!res.isSuccessful) return emptyMap()

        val tasks = res.body().orEmpty()

        return tasks
            .mapNotNull { task ->
                task.plan?.weekNumber?.let { it to task }
            }
            .groupBy({ it.first }, { it.second })
            .mapValues { (_, tasksForWeek) ->
                val completed =
                    tasksForWeek.count { it.status == "COMPLETED" }
                ((completed * 100f) / tasksForWeek.size).toInt()
            }
    }

    // --------------------------------------------------
    // NAVIGATION
    // --------------------------------------------------
    private fun openExperiencePreview(experience: PopularExperience) {
        ExperiencePreviewDialogFragment
            .newInstance(
                experience.title,
                experience.subtitle,
                experience.weekNumber
            )
            .show(
                parentFragmentManager,
                "ExperiencePreview_week_${experience.weekNumber}"
            )
    }
}
