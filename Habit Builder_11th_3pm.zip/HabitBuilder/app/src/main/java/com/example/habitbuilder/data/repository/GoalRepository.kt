package com.example.habitbuilder.data.repository

import com.example.habitbuilder.data.model.GoalResponse
import com.example.habitbuilder.network.ApiClient
import com.example.habitbuilder.network.GoalApi
import retrofit2.Response

class GoalRepository {

    private val api =
        ApiClient.createService(GoalApi::class.java)

    suspend fun getGoalsByProfile(
        profileId: String
    ): Response<List<GoalResponse>> {
        return api.getGoalsByProfile(profileId)
    }
}
