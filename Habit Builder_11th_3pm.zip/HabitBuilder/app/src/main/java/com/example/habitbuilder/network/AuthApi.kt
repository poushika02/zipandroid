package com.example.habitbuilder.network

import com.example.habitbuilder.data.model.LoginRequest
import com.example.habitbuilder.data.model.LoginResponse
import com.example.habitbuilder.data.model.SignupRequest
import com.example.habitbuilder.data.model.SignupResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST
data class LogoutRequest(
    val refreshToken: String
)
interface AuthApi {

    @POST("/api/v1/auth/register")
    suspend fun register(
        @Body request: SignupRequest
    ): Response<SignupResponse>

    @POST("/api/v1/auth/login")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<LoginResponse>
    @POST("/api/v1/auth/logout")
    suspend fun logout(
        @Body request: LogoutRequest
    ): Response<Unit>
}
