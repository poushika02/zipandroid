package com.example.habitbuilder.data.model

data class LoginResponse(
    val accessToken: String,
    val refreshToken: String
)
