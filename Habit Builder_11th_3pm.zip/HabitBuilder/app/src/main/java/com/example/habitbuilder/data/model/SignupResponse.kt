package com.example.habitbuilder.data.model

data class SignupResponse(
    val user: Any?,              // backend doesn’t specify structure yet
    val verificationToken: String
)
