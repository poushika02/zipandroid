package com.example.habitbuilder.ui.profile

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.habitbuilder.R
import com.example.habitbuilder.ui.home.HomeFragment
import com.google.android.material.card.MaterialCardView

class ProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        val emmaCard = view.findViewById<MaterialCardView>(R.id.profile_emma_card)
        val michaelCard = view.findViewById<MaterialCardView>(R.id.profile_michael_card)

        emmaCard.setOnClickListener {
            selectProfile("emma_001", "Emma")
        }

        michaelCard.setOnClickListener {
            selectProfile("michael_001", "Michael")
        }

        return view
    }

    /**
     * ✅ Save selected profile → HomeFragment auto-reads it
     */
    private fun selectProfile(profileId: String, profileName: String) {

        val prefs = requireContext()
            .getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)

        prefs.edit()
            .putString("profile_id", profileId)
            .putString("profile_name", profileName)
            .apply()

        parentFragmentManager.beginTransaction()
            .replace(
                R.id.contentContainer,
                HomeFragment()   // ✅ NO newInstance()
            )
            .commit()
    }
}
