package com.example.habitbuilder.data.model

data class GenerateWeekPlanRequest(
    val profileId: String,
    val userPrompt: String
)
