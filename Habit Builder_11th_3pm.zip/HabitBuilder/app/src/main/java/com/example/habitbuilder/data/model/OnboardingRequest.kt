package com.example.habitbuilder.data.model

data class OnboardingRequest(
    val basicInfo: BasicInfo,
    val challenges: List<String>,
    val interests: List<String>,
    val availability: Map<String, Any>
)
