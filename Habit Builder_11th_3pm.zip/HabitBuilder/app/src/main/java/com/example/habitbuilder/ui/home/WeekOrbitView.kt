package com.example.habitbuilder.ui.home

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View

class WeekOrbitView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    // ----------------------------
    // STATE
    // ----------------------------
    private var progressPercent: Int = 0   // 0..100

    // ----------------------------
    // PAINTS
    // ----------------------------
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 26f
        color = resolveThemeColor(android.R.attr.colorPrimary)
        alpha = 50
        strokeCap = Paint.Cap.ROUND
    }

    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 26f
        strokeCap = Paint.Cap.ROUND
        color = resolveThemeColor(android.R.attr.colorPrimary)
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 30f
        strokeCap = Paint.Cap.ROUND
        color = resolveThemeColor(android.R.attr.colorPrimary)
        alpha = 160
        setShadowLayer(18f, 0f, 0f, color)
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, glowPaint)
    }

    // ----------------------------
    // ANIMATION (GLOW ORBIT)
    // ----------------------------
    private var glowStartAngle = 270f
    private val glowSweep = 26f

    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 9000L
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            glowStartAngle = 270f + it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    // ----------------------------
    // DRAWING
    // ----------------------------
    private val arcRect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val size = width.coerceAtMost(height).toFloat()
        val padding = 16f

        arcRect.set(
            padding,
            padding,
            size - padding,
            size - padding
        )

        // 1️⃣ Background track
        canvas.drawArc(
            arcRect,
            0f,
            360f,
            false,
            trackPaint
        )

        // 2️⃣ Progress arc (REAL COMPLETION)
        val sweep =
            (progressPercent / 100f) * 360f

        if (sweep > 0f) {
            canvas.drawArc(
                arcRect,
                270f,
                sweep,
                false,
                progressPaint
            )
        }

        // 3️⃣ Decorative rotating glow
        if (progressPercent > 0) {
            canvas.drawArc(
                arcRect,
                glowStartAngle,
                glowSweep,
                false,
                glowPaint
            )
        }
    }

    // ----------------------------
    // PUBLIC API (CALLED BY ADAPTER)
    // ----------------------------
    fun setProgress(percent: Int) {
        val newValue = percent.coerceIn(0, 100)
        if (newValue == progressPercent) return

        progressPercent = newValue
        invalidate()
    }

    // ----------------------------
    // THEME COLOR
    // ----------------------------
    private fun resolveThemeColor(attr: Int): Int {
        val typedValue = TypedValue()
        context.theme.resolveAttribute(attr, typedValue, true)
        return typedValue.data
    }
}
