package com.example.habitbuilder.network

import com.example.habitbuilder.data.model.OnboardingRequest
import com.example.habitbuilder.data.model.OnboardingResponse
import com.example.habitbuilder.data.model.ProfileResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface OnboardingApi {

    @POST("/api/v1/onboarding/")
    suspend fun submitOnboarding(
        @Body request: OnboardingRequest
    ): Response<OnboardingResponse>

    // ✅ GET ALL PROFILES FOR LOGGED-IN USER
    @GET("/api/v1/profiles/")
    suspend fun getAllProfiles(): Response<List<ProfileResponse>>

}
