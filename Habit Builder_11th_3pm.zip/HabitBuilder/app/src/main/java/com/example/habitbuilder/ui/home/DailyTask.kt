package com.example.habitbuilder.ui.home

data class DailyTask(
    val id: String,
    val title: String,
    val description: String,
    val scheduledStart: String,
    val scheduledEnd: String,
    val dayOfWeek: Int,

    val status: TaskStatus,
    val score: Int,
    val feedback: String
) {
    val isLocked: Boolean
        get() = status == TaskStatus.COMPLETED

    val isCompleted: Boolean
        get() = score > 0

    val isSkipped: Boolean
        get() = feedback.isNotBlank()
}
