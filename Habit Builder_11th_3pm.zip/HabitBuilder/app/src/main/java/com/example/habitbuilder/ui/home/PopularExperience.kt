package com.example.habitbuilder.ui.home

data class PopularExperience(
    val weekNumber: Int,
    val title: String,
    val subtitle: String,
    val imageRes: Int,
    val completionPercent: Int // 👈 ADD
)

