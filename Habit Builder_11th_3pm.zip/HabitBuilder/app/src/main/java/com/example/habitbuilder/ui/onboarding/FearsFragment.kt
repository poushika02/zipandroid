package com.example.habitbuilder.ui.onboarding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.habitbuilder.R

class FearsFragment : Fragment() {



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(
            R.layout.fragment_onboarding_fears,
            container,
            false
        )

        val continueButton = view.findViewById<Button>(R.id.continueButton)
        val backButton = view.findViewById<TextView>(R.id.backText)

        continueButton.setOnClickListener {
            val fragment = ScheduleFragment()
            val bundle = arguments ?: Bundle()

            // TODO replace with real selected fears later
            bundle.putStringArrayList(
                "challenges",
                arrayListOf("Procrastination")
            )

            fragment.arguments = bundle

            parentFragmentManager.beginTransaction()
                .replace(R.id.onboarding_fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }

        backButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        return view
    }
}
