package com.example.habitbuilder.data.repository

import com.example.habitbuilder.data.model.LoginRequest
import com.example.habitbuilder.data.model.LoginResponse
import com.example.habitbuilder.data.model.SignupRequest
import com.example.habitbuilder.data.model.SignupResponse
import com.example.habitbuilder.network.ApiClient
import com.example.habitbuilder.network.AuthApi
import com.example.habitbuilder.network.LogoutRequest
import retrofit2.Response

class AuthRepository {

    private val authApi: AuthApi =
        ApiClient.createService(AuthApi::class.java)

    // ---------------- SIGNUP ----------------
    suspend fun registerUser(
        request: SignupRequest
    ): Response<SignupResponse> {
        return authApi.register(request)
    }

    // ---------------- LOGIN ----------------
    suspend fun loginUser(
        email: String,
        password: String
    ): Response<LoginResponse> {
        return authApi.login(
            LoginRequest(
                email = email,
                password = password
            )
        )
    }

    // ---------------- LOGOUT ----------------
    suspend fun logout(
        refreshToken: String
    ): Response<Unit> {
        return authApi.logout(
            LogoutRequest(refreshToken)
        )
    }
}
