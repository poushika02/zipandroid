package com.example.habitbuilder.data.model

data class PlanResponse(
    val id: String,
    val goalId: String,
    val profileId: String,
    val title: String,
    val weekNumber: Int,
    val status: String,
    val createdAt: String
)
