package com.example.habitbuilder.ui.home

enum class TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
