package com.example.habitbuilder.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.R
import com.example.habitbuilder.data.repository.TaskRepository
import kotlinx.coroutines.launch

class DailyPlanFragment : Fragment(),
    DailyTaskAdapter.TaskActionListener {

    private val viewModel: DailyPlanViewModel by viewModels()
    private lateinit var adapter: DailyTaskAdapter
    private val taskRepository = TaskRepository()

    // --------------------------------------------------
    // LIFECYCLE
    // --------------------------------------------------
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View =
        inflater.inflate(R.layout.fragment_daily_plan, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView =
            view.findViewById<RecyclerView>(R.id.rvDailyTasks)

        recyclerView.layoutManager =
            LinearLayoutManager(requireContext())

        adapter = DailyTaskAdapter(this)
        recyclerView.adapter = adapter

        // 🔁 Observe tasks (single source of truth for UI)
        viewModel.tasks.observe(viewLifecycleOwner) {
            adapter.submitList(it)
        }

        // 📦 TEMP: dummy data (replace with backend GET later)
        viewModel.setTasks(getDummyTasks())
    }

    // --------------------------------------------------
    // ADAPTER CALLBACKS (USER ACTION → PATCH → EVENT)
    // --------------------------------------------------
    override fun onComplete(taskId: String, rating: Int) {
        lifecycleScope.launch {
            val response =
                taskRepository.updateTaskStatus(
                    taskId = taskId,
                    status = "COMPLETED",
                    score = rating
                )

            if (response.isSuccessful) {

                // ✅ update local UI state
                viewModel.markCompleted(taskId, rating)

                // 🔔 notify HomeFragment (completion % refresh)
                parentFragmentManager.setFragmentResult(
                    "task_status_updated",
                    Bundle().apply {
                        putString("taskId", taskId)
                    }
                )
                requireActivity()
                    .supportFragmentManager
                    .setFragmentResult(
                        "task_status_updated",
                        Bundle().apply {
                            putString("taskId", taskId)
                        }
                    )
            }
        }
    }

    override fun onSkip(taskId: String, feedback: String) {
        lifecycleScope.launch {
            val response =
                taskRepository.updateTaskStatus(
                    taskId = taskId,
                    status = "COMPLETED",
                    score = 0,
                    feedback = feedback
                )

            if (response.isSuccessful) {

                viewModel.markSkipped(taskId, feedback)

                parentFragmentManager.setFragmentResult(
                    "task_status_updated",
                    Bundle().apply {
                        putString("taskId", taskId)
                    }
                )
                requireActivity()
                    .supportFragmentManager
                    .setFragmentResult(
                        "task_status_updated",
                        Bundle().apply {
                            putString("taskId", taskId)
                        }
                    )
            }
        }
    }

    // --------------------------------------------------
    // DUMMY DATA (BACKEND-COMPATIBLE)
    // --------------------------------------------------
    private fun getDummyTasks(): List<DailyTask> {
        return listOf(
            DailyTask(
                id = "task_1",
                title = "Walking",
                description = "",
                scheduledStart = "17:00",
                scheduledEnd = "18:00",
                dayOfWeek = 1,
                status = TaskStatus.PENDING,
                score = 0,
                feedback = ""
            ),
            DailyTask(
                id = "task_2",
                title = "Meditation",
                description = "",
                scheduledStart = "07:00",
                scheduledEnd = "07:15",
                dayOfWeek = 1,
                status = TaskStatus.PENDING,
                score = 0,
                feedback = ""
            )
        )
    }
}
