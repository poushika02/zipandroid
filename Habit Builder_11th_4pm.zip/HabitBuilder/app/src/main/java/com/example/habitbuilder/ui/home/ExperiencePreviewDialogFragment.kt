package com.example.habitbuilder.ui.home

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.R
import com.example.habitbuilder.data.repository.TaskRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ExperiencePreviewDialogFragment :
    DialogFragment(),
    DailyTaskAdapter.TaskActionListener {

    companion object {
        private const val TAG = "ExperiencePreview"
        private const val ARG_TITLE = "arg_title"
        private const val ARG_DESCRIPTION = "arg_description"
        private const val ARG_WEEK_NUMBER = "arg_week_number"

        fun newInstance(
            title: String,
            description: String,
            weekNumber: Int
        ) = ExperiencePreviewDialogFragment().apply {
            arguments = Bundle().apply {
                putString(ARG_TITLE, title)
                putString(ARG_DESCRIPTION, description)
                putInt(ARG_WEEK_NUMBER, weekNumber)
            }
        }
    }

    private val viewModel: DailyPlanViewModel by viewModels()
    private val taskRepository = TaskRepository()

    private lateinit var adapter: DailyTaskAdapter
    private lateinit var nextWeekBanner: View
    private lateinit var noTasksPlaceholder: View // ✅ ADDED

    private var weekNumber: Int = 1
    private var pollingJob: Job? = null
    private var isWeekLocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NO_TITLE, R.style.CenterDialogStyle)
        weekNumber = arguments?.getInt(ARG_WEEK_NUMBER) ?: 1
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View =
        inflater.inflate(R.layout.dialog_experience_preview, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        view.findViewById<TextView>(R.id.tvHeroTitle).text =
            arguments?.getString(ARG_TITLE).orEmpty()

        view.findViewById<TextView>(R.id.tvGoalDescription).text =
            arguments?.getString(ARG_DESCRIPTION).orEmpty()

        view.findViewById<View>(R.id.btnClose).setOnClickListener { dismiss() }

        nextWeekBanner = view.findViewById(R.id.nextWeekBanner)
        noTasksPlaceholder = view.findViewById(R.id.tvNoTasksPlaceholder) // ✅ ADDED

        val recyclerView = view.findViewById<RecyclerView>(R.id.rvDailyTasks)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        adapter = DailyTaskAdapter(this)
        recyclerView.adapter = adapter

        viewModel.tasks.observe(viewLifecycleOwner) { tasks ->

            Log.d(TAG, "Tasks for week $weekNumber = ${tasks.size}") // ✅ optional debug

            if (tasks.isEmpty()) {
                noTasksPlaceholder.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            } else {
                noTasksPlaceholder.visibility = View.GONE
                recyclerView.visibility = View.VISIBLE
                adapter.submitList(tasks)
            }
        }

        viewModel.showNextWeekBanner.observe(viewLifecycleOwner) { show ->
            nextWeekBanner.visibility = if (show) View.VISIBLE else View.GONE
            if (show) {
                isWeekLocked = true
                startPollingForNextWeek()
            }
        }

        loadTasksForWeek(false)
    }

    private fun loadTasksForWeek(fromPolling: Boolean) {
        if (fromPolling && isWeekLocked) return

        val profileId =
            requireContext()
                .getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)
                .getString("profile_id", null) ?: return

        lifecycleScope.launch {
            val response = taskRepository.getTasks(profileId)
            if (!response.isSuccessful) return@launch

            val tasks =
                response.body().orEmpty()
                    .filter { it.plan?.weekNumber == weekNumber }
                    .sortedBy { it.dayOfWeek ?: 1 }
                    .map {
                        DailyTask(
                            id = it.id,
                            title = it.title.orEmpty(),
                            description = it.description.orEmpty(),
                            scheduledStart = it.scheduledStart ?: "--",
                            scheduledEnd = it.scheduledEnd ?: "--",
                            dayOfWeek = it.dayOfWeek ?: 1,
                            status = (it.status ?: "PENDING").toTaskStatus(),
                            score = if (it.status == "COMPLETED") 5 else 0,
                            feedback = ""
                        )
                    }

            viewModel.setTasksForWeek(tasks)
        }
    }

    private fun startPollingForNextWeek() {
        if (pollingJob != null) return
        pollingJob = lifecycleScope.launch {
            while (true) {
                delay(10_000)
                loadTasksForWeek(true)
            }
        }
    }

    private fun patchTaskStatus(
        taskId: String,
        status: TaskStatus,
        score: Int?,
        feedback: String?
    ) {
        lifecycleScope.launch {
            taskRepository.updateTaskStatus(
                taskId,
                status.name,
                score,
                feedback
            )
        }
    }

    private fun notifyHome() {
        parentFragmentManager.setFragmentResult(
            "task_status_updated",
            Bundle.EMPTY
        )
    }

    override fun onComplete(taskId: String, rating: Int) {
        viewModel.markCompleted(taskId, rating)
        patchTaskStatus(taskId, TaskStatus.COMPLETED, rating, null)
        notifyHome()
    }

    override fun onSkip(taskId: String, feedback: String) {
        viewModel.markSkipped(taskId, feedback)
        patchTaskStatus(taskId, TaskStatus.COMPLETED, 0, feedback)
        notifyHome()
    }

    override fun onDestroyView() {
        pollingJob?.cancel()
        pollingJob = null
        super.onDestroyView()
    }
}
