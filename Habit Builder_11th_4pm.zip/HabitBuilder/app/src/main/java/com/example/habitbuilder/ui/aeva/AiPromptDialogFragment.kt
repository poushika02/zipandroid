package com.example.habitbuilder.ui.ai

import android.animation.ObjectAnimator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import com.example.habitbuilder.R
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton

class AiPromptDialogFragment : BottomSheetDialogFragment() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(R.layout.dialog_ai_prompt, container, false)

        val layoutInput = view.findViewById<View>(R.id.layoutInput)
        val layoutThinking = view.findViewById<View>(R.id.layoutThinking)
        val btnGenerate = view.findViewById<MaterialButton>(R.id.btnGenerate)
        val ivSpinner = view.findViewById<ImageView>(R.id.ivSpinner)
        val ivTick = view.findViewById<ImageView>(R.id.ivTick)

        btnGenerate.setOnClickListener {

            layoutInput.visibility = View.GONE
            layoutThinking.visibility = View.VISIBLE

            // ROTATION (thinking)
            val rotateAnim = ObjectAnimator.ofFloat(ivSpinner, View.ROTATION, 0f, 360f)
            rotateAnim.duration = 800
            rotateAnim.repeatCount = ObjectAnimator.INFINITE
            rotateAnim.interpolator = AccelerateDecelerateInterpolator()
            rotateAnim.start()

            // STOP ROTATION → SHOW TICK
            handler.postDelayed({

                rotateAnim.cancel()
                ivSpinner.animate()
                    .alpha(0f)
                    .setDuration(200)
                    .start()

                ivTick.animate()
                    .alpha(1f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setInterpolator(OvershootInterpolator())
                    .setDuration(400)
                    .start()

            }, 1500)

            // AUTO DISMISS AFTER 5s
            handler.postDelayed({
                if (isAdded) dismiss()
            }, 3000)
        }

        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacksAndMessages(null)
    }
}
