package com.example.habitbuilder.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class DailyPlanViewModel : ViewModel() {

    private val _tasks = MutableLiveData<List<DailyTask>>(emptyList())
    val tasks: LiveData<List<DailyTask>> = _tasks

    private val _showNextWeekBanner = MutableLiveData(false)
    val showNextWeekBanner: LiveData<Boolean> = _showNextWeekBanner

    /**
     * Used when loading tasks for a specific week
     */
    fun setTasksForWeek(list: List<DailyTask>) {
        _tasks.value = list
        evaluateWeekCompletion(list)
    }

    /**
     * Generic setter (kept for compatibility)
     */
    fun setTasks(list: List<DailyTask>) {
        _tasks.value = list
        evaluateWeekCompletion(list)
    }

    fun markCompleted(taskId: String, rating: Int) {
        val updated =
            _tasks.value.orEmpty().map {
                if (it.id == taskId) {
                    it.copy(
                        status = TaskStatus.COMPLETED,
                        score = rating,
                        feedback = ""
                    )
                } else it
            }

        _tasks.value = updated
        evaluateWeekCompletion(updated)
    }

    fun markSkipped(taskId: String, feedback: String) {
        val updated =
            _tasks.value.orEmpty().map {
                if (it.id == taskId) {
                    it.copy(
                        status = TaskStatus.COMPLETED,
                        score = 0,
                        feedback = feedback
                    )
                } else it
            }

        _tasks.value = updated
        evaluateWeekCompletion(updated)
    }

    /**
     * 🔥 Single source of truth:
     * Week is complete ONLY if all tasks are COMPLETED
     */
    private fun evaluateWeekCompletion(tasks: List<DailyTask>) {
        val isComplete =
            tasks.isNotEmpty() &&
                    tasks.all { it.status == TaskStatus.COMPLETED }

        _showNextWeekBanner.value = isComplete
    }
}
