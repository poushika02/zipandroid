package com.example.habitbuilder.ui.home

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.habitbuilder.R
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class DailyTaskAdapter(
    private val listener: TaskActionListener
) : ListAdapter<DailyTask, DailyTaskAdapter.VH>(Diff) {

    object Diff : DiffUtil.ItemCallback<DailyTask>() {
        override fun areItemsTheSame(a: DailyTask, b: DailyTask) = a.id == b.id
        override fun areContentsTheSame(a: DailyTask, b: DailyTask) = a == b
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_daily_task, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(getItem(position))
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {

        private val title = view.findViewById<TextView>(R.id.tvTaskTitle)
        private val time = view.findViewById<TextView>(R.id.tvTaskTime)
        private val description = view.findViewById<TextView>(R.id.tvTaskDescription)
        private val day = view.findViewById<TextView>(R.id.tvTaskDay)

        private val btnComplete = view.findViewById<ImageView>(R.id.btnComplete)
        private val btnSkip = view.findViewById<ImageView>(R.id.btnNotComplete)

        private val expandable = view.findViewById<View>(R.id.layoutExpandable)
        private val ratingBar = view.findViewById<RatingBar>(R.id.ratingBar)
        private val reasonLayout =
            view.findViewById<TextInputLayout>(R.id.reasonLayout)
        private val reasonEdit =
            view.findViewById<TextInputEditText>(R.id.etReason)
        private val submitBtn =
            view.findViewById<MaterialButton>(R.id.btnSend)

        private val doneText = view.findViewById<TextView>(R.id.tvDone)

        fun bind(task: DailyTask) {

            // -----------------------------
            // BASIC INFO
            // -----------------------------
            title.text = task.title
            time.text = "${task.scheduledStart} - ${task.scheduledEnd}"

            description.text = task.description
            description.visibility =
                if (task.description.isNullOrBlank()) View.GONE else View.VISIBLE

            day.text = getDayName(task.dayOfWeek)

            // --------------------------------------------------
            // 🔒 LOCKED TASK (COMPLETED / SKIPPED)
            // --------------------------------------------------
            if (task.isLocked) {
                btnComplete.visibility = View.GONE
                btnSkip.visibility = View.GONE
                expandable.visibility = View.GONE
                submitBtn.visibility = View.GONE

                doneText.visibility = View.VISIBLE
                doneText.text =
                    if (task.isCompleted) "Completed" else "Skipped"

                itemView.alpha = 0.6f
                return
            }

            // --------------------------------------------------
            // ACTIVE TASK
            // --------------------------------------------------
            itemView.alpha = 1f
            doneText.visibility = View.GONE
            btnComplete.visibility = View.VISIBLE
            btnSkip.visibility = View.VISIBLE

            // reset expandable UI every bind (IMPORTANT)
            expandable.visibility = View.GONE
            ratingBar.visibility = View.GONE
            reasonLayout.visibility = View.GONE
            submitBtn.visibility = View.GONE
            ratingBar.rating = 0f
            reasonEdit.setText("")

            // -----------------------------
            // COMPLETE FLOW (RATING)
            // -----------------------------
            btnComplete.setOnClickListener {
                expandable.visibility = View.VISIBLE
                ratingBar.visibility = View.VISIBLE
                reasonLayout.visibility = View.GONE
                submitBtn.visibility = View.GONE
            }

            ratingBar.setOnRatingBarChangeListener { _, rating, fromUser ->
                if (fromUser && rating > 0) {
                    submitBtn.visibility = View.VISIBLE
                }
            }

            // -----------------------------
            // SKIP FLOW (FEEDBACK)
            // -----------------------------
            btnSkip.setOnClickListener {
                expandable.visibility = View.VISIBLE
                ratingBar.visibility = View.GONE
                reasonLayout.visibility = View.VISIBLE
                submitBtn.visibility = View.GONE
            }

            reasonEdit.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    submitBtn.visibility =
                        if (!s.isNullOrBlank()) View.VISIBLE else View.GONE
                }

                override fun beforeTextChanged(
                    s: CharSequence?, start: Int, count: Int, after: Int
                ) {}

                override fun onTextChanged(
                    s: CharSequence?, start: Int, before: Int, count: Int
                ) {}
            })

            // -----------------------------
            // SUBMIT
            // -----------------------------
            submitBtn.setOnClickListener {
                if (ratingBar.visibility == View.VISIBLE) {
                    val rating = ratingBar.rating.toInt()
                    if (rating > 0) {
                        listener.onComplete(task.id, rating)
                    }
                } else {
                    val feedback =
                        reasonEdit.text?.toString()?.trim().orEmpty()
                    if (feedback.isNotBlank()) {
                        listener.onSkip(task.id, feedback)
                    }
                }
            }
        }
    }

    // --------------------------------------------------
    // DAY NAME HELPER
    // --------------------------------------------------
    private fun getDayName(day: Int): String = when (day) {
        1 -> "Monday"
        2 -> "Tuesday"
        3 -> "Wednesday"
        4 -> "Thursday"
        5 -> "Friday"
        6 -> "Saturday"
        7 -> "Sunday"
        else -> ""
    }

    // --------------------------------------------------
    // CALLBACKS → FRAGMENT
    // --------------------------------------------------
    interface TaskActionListener {
        fun onComplete(taskId: String, rating: Int)
        fun onSkip(taskId: String, feedback: String)
    }
}
