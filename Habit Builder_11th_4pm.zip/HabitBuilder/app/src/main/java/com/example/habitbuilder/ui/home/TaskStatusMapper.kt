package com.example.habitbuilder.ui.home

/**
 * Maps backend task status (String) to UI enum safely.
 *
 * Backend sends:
 *  - "PENDING"
 *  - "IN_PROGRESS"
 *  - "COMPLETED"
 *
 * Any unknown / null value → PENDING
 */
fun String.toTaskStatus(): TaskStatus {
    return when (this.uppercase()) {
        "COMPLETED" -> TaskStatus.COMPLETED
        "IN_PROGRESS" -> TaskStatus.IN_PROGRESS
        "PENDING" -> TaskStatus.PENDING
        else -> TaskStatus.PENDING
    }
}
