package com.example.habitbuilder.ui.login

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habitbuilder.HabitBuilderApp
import com.example.habitbuilder.data.repository.AuthRepository
import com.example.habitbuilder.data.repository.OnboardingRepository
import kotlinx.coroutines.launch

class LoginViewModel : ViewModel() {

    private val repository = AuthRepository()
    private val onboardingRepository = OnboardingRepository()

    fun login(
        email: String,
        password: String,
        onNavigateToOnboarding: () -> Unit,
        onNavigateToHome: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                // 1️⃣ LOGIN
                val response = repository.loginUser(email, password)

                if (!response.isSuccessful || response.body() == null) {
                    onError("Login failed (${response.code()})")
                    return@launch
                }

                val accessToken = response.body()!!.accessToken
                val refreshToken = response.body()!!.refreshToken

                // 2️⃣ SAVE TOKENS
                val prefs = HabitBuilderApp.appContext
                    .getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)

                prefs.edit()
                    .putString("access_token", accessToken)
                    .putString("refresh_token", refreshToken)
                    .apply()

                // 3️⃣ FETCH PROFILES
                val profilesResponse = onboardingRepository.getAllProfiles()

                if (!profilesResponse.isSuccessful) {
                    onError("Failed to fetch profiles")
                    return@launch
                }

                val profiles = profilesResponse.body() ?: emptyList()
                Log.d("Profiles", "Profiles from DB = $profiles")

                // 4️⃣ SAVE PROFILE DATA (🔥 FIX)
                if (profiles.isNotEmpty()) {
                    val profile = profiles.first()

                    prefs.edit()
                        .putString("profile_id", profile.id)     // ✅ REQUIRED
                        .putString("profile_name", profile.name) // ✅ UI
                        .apply()
                }

                // 5️⃣ NAVIGATION DECISION
                if (profiles.isEmpty()) {
                    onNavigateToOnboarding()
                } else {
                    onNavigateToHome()
                }

            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Network error")
            }
        }
    }
}
