package com.example.habitbuilder.ui.onboarding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.habitbuilder.R
import com.google.android.material.card.MaterialCardView
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat

class ScheduleFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_onboarding_schedule, container, false)

        val cardWorking = view.findViewById<MaterialCardView>(R.id.card_working)
        val cardStudent = view.findViewById<MaterialCardView>(R.id.card_student)
        val cardOpenSchedule = view.findViewById<MaterialCardView>(R.id.card_open_schedule)

        val sectionWorkingDetails = view.findViewById<LinearLayout>(R.id.section_working_details)
        val sectionStudentDetails = view.findViewById<LinearLayout>(R.id.section_student_details)
        val sectionOpenScheduleDetails = view.findViewById<LinearLayout>(R.id.section_open_schedule_details)

        val workingStartTime = view.findViewById<Button>(R.id.working_start_time)
        val workingEndTime = view.findViewById<Button>(R.id.working_end_time)
        val studentClassStartTime = view.findViewById<Button>(R.id.student_class_start_time)
        val studentClassEndTime = view.findViewById<Button>(R.id.student_class_end_time)
        val studentFreeStartTime = view.findViewById<Button>(R.id.student_free_start_time)
        val studentFreeEndTime = view.findViewById<Button>(R.id.student_free_end_time)
        val openScheduleStartTime = view.findViewById<Button>(R.id.open_schedule_start_time)
        val openScheduleEndTime = view.findViewById<Button>(R.id.open_schedule_end_time)

        val continueButton = view.findViewById<Button>(R.id.continue_button)
        val backButton = view.findViewById<TextView>(R.id.back_button)

        cardWorking.setOnClickListener {
            sectionWorkingDetails.visibility = View.VISIBLE
            sectionStudentDetails.visibility = View.GONE
            sectionOpenScheduleDetails.visibility = View.GONE
        }

        cardStudent.setOnClickListener {
            sectionWorkingDetails.visibility = View.GONE
            sectionStudentDetails.visibility = View.VISIBLE
            sectionOpenScheduleDetails.visibility = View.GONE
        }

        cardOpenSchedule.setOnClickListener {
            sectionWorkingDetails.visibility = View.GONE
            sectionStudentDetails.visibility = View.GONE
            sectionOpenScheduleDetails.visibility = View.VISIBLE
        }

        workingStartTime.setOnClickListener { showTimePicker(workingStartTime) }
        workingEndTime.setOnClickListener { showTimePicker(workingEndTime) }
        studentClassStartTime.setOnClickListener { showTimePicker(studentClassStartTime) }
        studentClassEndTime.setOnClickListener { showTimePicker(studentClassEndTime) }
        studentFreeStartTime.setOnClickListener { showTimePicker(studentFreeStartTime) }
        studentFreeEndTime.setOnClickListener { showTimePicker(studentFreeEndTime) }
        openScheduleStartTime.setOnClickListener { showTimePicker(openScheduleStartTime) }
        openScheduleEndTime.setOnClickListener { showTimePicker(openScheduleEndTime) }

        continueButton.setOnClickListener {
            val fragment = OnboardingCompleteFragment()
            fragment.arguments = arguments

            parentFragmentManager.beginTransaction()
                .replace(R.id.onboarding_fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }

        backButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        return view
    }

    private fun showTimePicker(button: Button) {
        val picker = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_12H)
            .setHour(12)
            .setMinute(0)
            .setTitleText("Select Time")
            .build()

        picker.addOnPositiveButtonClickListener { 
            val hour = picker.hour
            val minute = picker.minute
            button.text = String.format("%02d:%02d", hour, minute)
        }

        picker.show(childFragmentManager, "timePicker")
    }
}
