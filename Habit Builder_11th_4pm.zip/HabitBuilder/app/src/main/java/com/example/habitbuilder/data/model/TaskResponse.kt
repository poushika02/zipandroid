package com.example.habitbuilder.data.model

/**
 * Response model from backend
 * Used by TodayTasksAdapter + DailyPlanFragment
 */
data class TaskResponse(
    val id: String,
    val title: String?,              // nullable → backend safe
    val description: String?,
    val scheduledStart: String?,
    val scheduledEnd: String?,
    val dayOfWeek: Int?,
    val status: String?,
    val plan: TaskPlanResponse?
)

/**
 * Nested response object
 */
data class TaskPlanResponse(
    val weekNumber: Int?
)
