package com.example.habitbuilder.data.repository

import com.example.habitbuilder.network.ApiClient

class ProfileRepository {

    suspend fun getAllProfiles() =
        ApiClient.onboardingApi.getAllProfiles()
}
