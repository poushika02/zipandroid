package com.example.habitbuilder.data.local

import android.content.Context
import android.content.SharedPreferences

class UserPrefs(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(
            "auth_prefs",
            Context.MODE_PRIVATE
        )

    companion object {
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_PROFILE_ID = "profile_id"
        private const val KEY_PROFILE_NAME = "profile_name"
    }

    // ---------------- SAVE ----------------

    fun saveAccessToken(token: String) {
        prefs.edit().putString(KEY_ACCESS_TOKEN, token).apply()
    }

    fun saveRefreshToken(token: String) {
        prefs.edit().putString(KEY_REFRESH_TOKEN, token).apply()
    }

    fun saveProfileId(profileId: String) {
        prefs.edit().putString(KEY_PROFILE_ID, profileId).apply()
    }

    fun saveProfileName(name: String) {
        prefs.edit().putString(KEY_PROFILE_NAME, name).apply()
    }

    // ---------------- GET ----------------

    fun getAccessToken(): String? {
        return prefs.getString(KEY_ACCESS_TOKEN, null)
    }

    fun getRefreshToken(): String? {
        return prefs.getString(KEY_REFRESH_TOKEN, null)
    }

    fun getProfileId(): String? {
        return prefs.getString(KEY_PROFILE_ID, null)
    }

    fun getProfileName(): String? {
        return prefs.getString(KEY_PROFILE_NAME, null)
    }

    // ---------------- CLEAR ----------------

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
